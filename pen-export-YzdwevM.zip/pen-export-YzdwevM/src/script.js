/* -----------------------

clock

------------------------ */
function updateTime () {
    var zeDate = new Date();
    var h = zeDate.getHours();
    var m = zeDate.getMinutes();
    var s = zeDate.getSeconds();
    var e = "AM"
    
    var p = document.querySelector(".clock");
    
    
    if (h > 12) {
        h = h - 12;
        e = "PM";
    }
    
    if (h < 10) {
        h = "" + h;
    }
    if (m < 10) {
        m = "0" + m;
    }
    if (s < 10) {
     s = "0" + s;
}
    
    p.textContent = h + ":" + m + ":" +  s + " " + e; 
    
    
}

updateTime();

setInterval(function () {
    updateTime();
}, 1000);